#include "polygon.h"

#ifndef IO_H
#define IO_H

int insertDots(Quadrilateral **self);
void convexOutput(int convex);
void areaOutput(double area);
#endif
