#include "array.h"

#ifndef IO_H
#define IO_H

int printOutput(Array *array, char *key);
int inputValue(Array **array);
int arrayPrint(Array *self);

#endif
